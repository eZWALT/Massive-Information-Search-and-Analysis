"""
.. module:: MRKmeans

MRKmeans
*************

:Description: MRKmeans

    Iterates the MRKmeansStep script

:Authors: bejar
    

:Version: 

:Created on: 17/07/2017 10:16 

"""

from MRKmeansStep import MRKmeansStep
import shutil
import argparse
import os
import time
from mrjob.util import to_lines

__author__ = 'bejar'

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--prot', default='prototypes.txt', help='Initial prototpes file')
    parser.add_argument('--docs', default='documents.txt', help='Documents data')
    parser.add_argument('--iter', default=10, type=int, help='Number of iterations')
    parser.add_argument('--ncores', default=8, type=int, help='Number of parallel processes to use')

    args = parser.parse_args()
    assign = {}

    # Copies the initial prototypes
    cwd = os.getcwd()
    shutil.copy(cwd + '/' + args.prot, cwd + '/prototypes0.txt')
    nomove = False  # Stores if there has been changes in the current iteration
    old_proto = {}
    
    
    #return values
    num_iterations = 0
    timer1 = time.time()
    time_first_iter = 0
    first_iter = True
    distortions = []
    for i in range(args.iter):
        num_iterations += 1
        #print(f"Iteration {i+1} ...")
        # The --file flag tells to MRjob to copy the file to HADOOP
        # The --prot flag tells to MRKmeansStep where to load the prototypes from
        mr_job1 = MRKmeansStep(args=['-r', 'local', args.docs,
                                     '--file', cwd + f"/prototypes{i}.txt",
                                     '--prot', cwd + f"/prototypes{i}.txt",
                                     '--num-cores', str(args.ncores)])

        # Runs the script
        with mr_job1.make_runner() as runner1:
            runner1.run()
            new_assign = {}
            new_proto = {}
            # Process the results of the script iterating the (key,value) pairs
            filename = "prototypes_final.txt" if i == args.iter-1 else f"prototypes{i+1}.txt"
            file = open(f"{cwd}/{filename}","w")
            
            for key, (value, distortion) in mr_job1.parse_output(runner1.cat_output()):
                prototype = ""
                distortions.append(distortion)
                for word, freq in value:
                    prototype += f"{word}+{freq} "
                    new_proto[word] = freq
                
                new_proto_items = list(new_proto.items())
                document = [item[0] for item in value]
                    
                file.write(f"{key}:{prototype}\n")

            file.close()
            if new_proto == old_proto:
                nomove = True 
            old_proto = new_proto
            
            
        
        if first_iter: 
            timer = time.time()
            first_iter = False 
            time_first_iter = timer - timer1

        if nomove:  # If there is no changes in two consecutive iteration we can stop
            #print("Algorithm converged")
            break
        
    timer2 = time.time()  


    print(f"{time_first_iter},{timer2-timer1},{num_iterations},{distortion}")
    # Now the last prototype file should have the results
